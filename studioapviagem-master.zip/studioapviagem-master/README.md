# Firebase Studioimport { AlertDialog, AlertDialogTrigger, AlertDialogContent, ... } from "@/components/ui/alert-dialog";


This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.
