
package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class Service {

    public String getDetails() {
        return "Service Details";
    }
}
    