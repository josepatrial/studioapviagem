public class Utils {
    public static String reverseString(String input) {
        return new StringBuilder(input).reverse().toString();
    }
}