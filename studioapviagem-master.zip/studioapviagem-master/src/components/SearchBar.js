
      // SearchBar.js
      import React from 'react';

      function SearchBar() {
        return (
          <input type="text" placeholder="Search..." />
        );
      }

      export default SearchBar;
    